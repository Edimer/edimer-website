# SYSTEM_DESIGN.md

## Pregunta técnica

> ¿Cómo va la producción de leche esta semana, por granja y por vaca, frente a la semana anterior?

## Datos

Carpeta `datos/`: un archivo de Excel por semana. Cada archivo tiene una hoja llamada `produccion` con un registro por vaca y por día:

| Columna | Qué significa |
|---|---|
| `granja` | Nombre de la granja |
| `vaca` | Identificación de la vaca |
| `raza` | Holstein, Jersey, Normando o Girolando |
| `fecha` | Día del registro |
| `dias_lactancia` | Días desde el último parto |
| `kg_leche` | Leche producida ese día, en kg |

- Puede haber registros con `kg_leche` vacío o negativo: son errores de digitación.

### Nombre de los archivos

Todos los archivos siguen el mismo formato: `produccion_AAAA_semana_NN.xlsx` (por ejemplo, `produccion_2026_semana_41.xlsx`).

- El año y el número de semana se leen del nombre del archivo.
- La **semana actual** es la de año y número más altos; la **semana anterior**, la que le precede. El orden debe funcionar también al cambiar de año (la semana 1 de 2027 va después de la 52 de 2026).
- Para agregar una semana basta con guardar su archivo en `datos/` con ese formato de nombre.
- Los archivos que no sigan el formato se ignoran.

## Qué debe mostrar el informe

1. **Resumen de la semana**: leche total, número de vacas en ordeño y promedio de leche por vaca por día, comparados con la semana anterior.
2. **Producción por granja**: una tabla con la semana actual, la anterior y el cambio en porcentaje.
3. **Curva de lactancia por raza**: un gráfico de leche diaria frente a días de lactancia, con todas las semanas disponibles.
4. **Vacas para revisar**: las vacas cuyo promedio de la semana actual está por debajo del 80 % del promedio de su raza en su misma etapa de lactancia.
   - Etapas: temprana (1 a 100 días), media (101 a 200 días) y tardía (más de 200 días).
5. **Datos con problemas**: una tabla con los registros vacíos o negativos. No entran en los cálculos, pero nunca se eliminan sin mostrarlos.

El informe debe ser un solo archivo `informe.html` que se pueda abrir y compartir sin nada más. El texto va en español.

## Cómo se organiza el código

- `R/leer_datos.R`: lee los archivos de `datos/`, revisa que tengan las columnas esperadas y separa los registros con problemas.
- `R/resumir.R`: calcula los resúmenes por semana, por granja y la lista de vacas para revisar.
- `tests/`: pruebas de esas funciones, con datos pequeños escritos dentro de las mismas pruebas.
- `informe.qmd`: usa esas funciones y arma tablas, gráficos y conclusiones.

## Cómo sabremos que está bien

- Las pruebas pasan.
- `quarto render informe.qmd` genera `informe.html` sin errores.
- Si se agrega el archivo de una nueva semana a `datos/` y se vuelve a generar el informe, todo se actualiza solo, sin tocar el código.
- Los registros con problemas aparecen en el informe.

## Fuera de alcance

Modelos de predicción, bases de datos y publicar el informe en internet.
