# AGENTS.md

## Qué es este proyecto

Un informe semanal de producción de leche de tres granjas, hecho con R y Quarto. Los datos son simulados, para el taller.

Lo que hay que construir está descrito en `SYSTEM_DESIGN.md`: léelo completo antes de empezar.

## Cómo está organizado

- `datos/`: un archivo de Excel por semana. **Nunca se modifican.**
- `R/`: las funciones en R (créala si no existe).
- `tests/`: las pruebas de esas funciones (créala si no existe).
- `informe.qmd`: el informe. Al generarlo produce `informe.html`.

## Comandos

- Pruebas: `Rscript -e "testthat::test_dir('tests')"`
- Informe: `quarto render informe.qmd`

Si no encuentras `Rscript`, búscalo en la carpeta donde está instalado R (en Windows suele ser `C:\Program Files\R\R-x.y.z\bin`).

## Cómo trabajar

- Si falta un paquete de R o Quarto, instálalo y dime qué instalaste.
- Trabaja por partes: primero las funciones, luego las pruebas, al final el informe.
- Después de cada parte, ejecuta las pruebas y cuéntame el resultado real.
- Explica brevemente qué hiciste y por qué.

## Límites

- No modifiques ni borres los archivos de `datos/`.
- No inventes datos ni resultados.
- Pide permiso antes de borrar cualquier archivo.
- No guardes contraseñas ni llaves en ningún archivo.
